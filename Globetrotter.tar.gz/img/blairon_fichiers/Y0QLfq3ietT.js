/*!CK:2552993706!*//*1455137894,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["nyshi"]); }

__d('NotificationBeeperContainer',['NotificationBeeper.react','React','ReactDOM'],function a(b,c,d,e,f,g,h,i,j){if(c.__markCompiled)c.__markCompiled();var k={renderBeeper:function(l,m){j.render(i.createElement(h,l),m);}};f.exports=k;},null);