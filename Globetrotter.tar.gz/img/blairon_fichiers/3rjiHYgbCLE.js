/*!CK:519604204!*//*1455137897,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["jOnlR"]); }

__d('MessengerTabIndices',[],function a(b,c,d,e,f,g){'use strict';if(c.__markCompiled)c.__markCompiled();var h={NEW_MESSAGE_TOKENIZER:9998,COMPOSER_INPUT:9999};f.exports=h;},null);