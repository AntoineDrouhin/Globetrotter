/*!CK:3996748197!*//*1455132199,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["w762U"]); }

__d('FBRTCCallSummaryUploader',['Banzai','FBRTCCallSummary','FBRTCCallSummaryStore'],function a(b,c,d,e,f,g,h,i,j){if(c.__markCompiled)c.__markCompiled();var k={init:function(){var l=j.getInstance();h.subscribe(h.SEND,function(){i.logSavedSummaries(l);});}};f.exports=k;},null);