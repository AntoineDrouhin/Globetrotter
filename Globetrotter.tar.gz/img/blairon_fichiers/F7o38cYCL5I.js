/*!CK:1574467348!*//*1454490811,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["HxQnv"]); }

__d('P2PPlatformContextShippingOptionShape',['React'],function a(b,c,d,e,f,g,h){'use strict';if(c.__markCompiled)c.__markCompiled();var i=h.PropTypes,j=i.shape({formattedShippingPrice:i.string,formattedSubtotal:i.string,formattedTax:i.string,formattedTotal:i.string,id:i.string,rawTotal:i.string,title:i.string});f.exports=j;},null);