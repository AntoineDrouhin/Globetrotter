/*!CK:4083988797!*//*1454776406,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["HidLU"]); }

__d('canUseReactEditor',['UserAgent'],function a(b,c,d,e,f,g,h){'use strict';if(c.__markCompiled)c.__markCompiled();var i=typeof b.getSelection==='function',j=i&&((h.isPlatform('iOS')||h.isPlatform('Linux')||h.isPlatform('Mac OS X')||h.isPlatform('Windows')||h.isPlatform('Chrome OS'))&&(h.isEngine('EdgeHTML >= 12')||h.isEngine('Gecko >= 16')||h.isEngine('Trident >= 5')||h.isEngine('WebKit >= 533.16')&&!h.isBrowser('Mobile Safari < 6')));function k(){return j;}f.exports=k;},null);