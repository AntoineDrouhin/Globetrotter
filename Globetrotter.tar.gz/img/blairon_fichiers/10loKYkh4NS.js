/*!CK:4162911204!*//*1455035226,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["vqYfr"]); }

__d('P2PPlatformContextBannerShape',['React'],function a(b,c,d,e,f,g,h){'use strict';if(c.__markCompiled)c.__markCompiled();var i=h.PropTypes,j=i.shape({shouldShowToBuyer:i.bool,shouldShowToSeller:i.bool,shouldShowPayNux:i.bool});f.exports=j;},null);