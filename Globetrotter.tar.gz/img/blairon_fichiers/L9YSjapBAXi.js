/*!CK:1531355397!*//*1454956184,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["FN\/BI"]); }

__d('P2PSenderNUXChatThreadBanner.react',['P2PBannerType','P2PPaymentLoggerEventFlow','P2PSendMoneyNUXChatThreadBanner.react','React','fbt'],function a(b,c,d,e,f,g,h,i,j,k,l){'use strict';if(c.__markCompiled)c.__markCompiled();var m=k.PropTypes,n=k.createClass({displayName:'P2PSenderNUXChatThreadBanner',propTypes:{threadID:m.string.isRequired},render:function(){return (k.createElement(j,{bannerType:h.SENDER_NUX,bodyText:l._("C\u2019est gratuit et s\u00e9curis\u00e9."),buttonText:l._("Commencer"),loggerEventFlow:i.UI_FLOW_SENDER_NUX_CHAT_THREAD_BANNER,threadID:this.props.threadID,titleText:l._("Vous pouvez maintenant envoyer de l\u2019argent\u00a0!")}));}});f.exports=n;},null);