/*!CK:3311507856!*//*1455141211,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["kCv+r"]); }

__d('MercuryGiftSnippetRenderer',['fbt'],function a(b,c,d,e,f,g,h){'use strict';if(c.__markCompiled)c.__markCompiled();var i={renderText:function(j,k){return j?h._("Vous avez envoy\u00e9 un message de Saint-Valentin."):h._("{name} a envoy\u00e9 un message de Saint-Valentin.",[h.param('name',k)]);}};f.exports=i;},null);