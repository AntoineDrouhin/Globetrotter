/*!CK:2388137112!*//*1455131700,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["qU3IU"]); }

__d("XForwardingNUXSeenController",["XController"],function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports=c("XController").create("\/chat\/forwarding_nux_seen\/",{});},null);