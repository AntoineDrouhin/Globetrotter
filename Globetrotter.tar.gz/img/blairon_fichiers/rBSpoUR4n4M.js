/*!CK:895031368!*//*1455131992,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["6RWgJ"]); }

__d('MessengerContactActions',['keyMirror'],function a(b,c,d,e,f,g,h){'use strict';if(c.__markCompiled)c.__markCompiled();f.exports=h({MESSAGE:null,PROFILE:null,REMOVE:null,SELECT:null});},null);