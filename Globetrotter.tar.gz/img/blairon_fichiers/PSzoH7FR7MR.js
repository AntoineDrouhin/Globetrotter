/*!CK:970361037!*//*1455137896,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["botWg"]); }

__d("XDOMScannerResultsController",["XController"],function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports=c("XController").create("\/mac_nerd_son\/",{});},null);