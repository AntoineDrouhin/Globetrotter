/*!CK:2745934089!*//*1455132137,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["MUDeP"]); }

__d('P2PPlatformContextShape',['P2PPlatformContextBannerShape','P2PPlatformContextProductItemShape','P2PPlatformContextShippingOptionShape','React'],function a(b,c,d,e,f,g,h,i,j,k){'use strict';if(c.__markCompiled)c.__markCompiled();var l=k.PropTypes,m=l.shape({id:l.string,banner:h,buyerID:l.string,product:i,sellerID:l.string,shippingOptions:l.arrayOf(j)});f.exports=m;},null);