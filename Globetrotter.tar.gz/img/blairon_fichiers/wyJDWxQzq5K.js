/*!CK:1220535069!*//*1453754708,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["s58tu"]); }

__d('MercuryNonEmployeeTypeaheadRenderer',['DOM','CompactTypeaheadRenderer','cx','fbt'],function a(b,c,d,e,f,g,h,i,j,k){'use strict';if(c.__markCompiled)c.__markCompiled();function l(m,n){var o=i(m,n);if(m.non_employee){var p=h.create('span',{className:"_52l8 highlight"},k._("(Non employ\u00e9)")),q=h.scry(o,'.subtext')[0];if(q){h.prependContent(q,'\u00b7');h.prependContent(q,p);}}return o;}f.exports=l;},null);