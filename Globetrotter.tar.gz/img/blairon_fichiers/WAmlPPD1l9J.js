/*!CK:807702335!*//*1454722040,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["8eJ2b"]); }

__d('legacy:PhotoSnowliftAds',['PhotoSnowliftAds'],function a(b,c,d,e){if(c.__markCompiled)c.__markCompiled();b.PhotoSnowliftAds=c('PhotoSnowliftAds');},3);