/*!CK:1727735235!*//*1454656319,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["3Ad9l"]); }

__d("XC2CPayNUXBannerImpressionsUpdateController",["XController"],function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports=c("XController").create("\/c2c\/pay_nux_banner_impressions\/_update\/",{});},null);