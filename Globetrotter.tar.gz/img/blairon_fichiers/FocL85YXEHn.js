/*!CK:1216357909!*//*1455230334,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["Zgwdr"]); }

__d('MessagingGiftWrapConstants',[],function a(b,c,d,e,f,g){'use strict';if(c.__markCompiled)c.__markCompiled();var h='gift_wrap',i='gift_unwrapped',j='valentines2016';f.exports={TAG_PREFIX:h,UNWRAPPED_TAG:i,VALENTINES_GIFT:j};},null);